/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/

function polling() {
    // console.log("polling");
    setTimeout(polling, 1000 * 30);
}
polling();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jaHJvbWUtZXh0ZW5zaW9uLXR5cGVzY3JpcHQtc3RhcnRlci8uL3NyYy9iYWNrZ3JvdW5kLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gcG9sbGluZygpIHtcbiAgICAvLyBjb25zb2xlLmxvZyhcInBvbGxpbmdcIik7XG4gICAgc2V0VGltZW91dChwb2xsaW5nLCAxMDAwICogMzApO1xufVxucG9sbGluZygpO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9